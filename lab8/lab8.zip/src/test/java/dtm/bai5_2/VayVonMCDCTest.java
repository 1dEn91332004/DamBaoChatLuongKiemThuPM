package dtm.bai5_2;

import dtm.bai5_1.BankLoanUtils;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

/**
 * BÀI 5.2 - VIẾT TEST TESTNG TỪ MC/DC
 * Tập test cases tối thiểu đạt MC/DC gồm 5 cases (Row 2, 3, 4, 6, 10).
 */
public class VayVonMCDCTest {

    // Row 2: A=T, B=T, C=T, D=F -> Result = True (Cặp chứng minh độc lập cho C, A,
    // B khi lật)
    @Test(description = "MCDC Row 2: Baseline (Đủ tuổi, Đủ thu nhập, Có tài sản, Tín dụng thấp)")
    public void testMCDC_Baseline_AllConditionsSatisfiedByAsset() {
        boolean actual = BankLoanUtils.duDieuKienVay(25, 15_000_000, true, 600);
        Assert.assertTrue(actual, "Lỗi: Đáng lẽ KHÁCH HÀNG PHẢI ĐƯỢC VAY (Vì thoả mãn cơ bản và có Tài sản)");
    }

    // Row 3: A=T, B=T, C=F, D=T -> Result = True (Chứng minh D độc lập)
    @Test(description = "MCDC Row 3: TinDungDocLap_LonHon700 (Đủ tuổi, Đủ thu nhập, Ko tài sản, Tín dụng CAO)")
    public void testMCDC_TinDungDocLap_LonHon700() {
        boolean actual = BankLoanUtils.duDieuKienVay(25, 15_000_000, false, 750);
        Assert.assertTrue(actual, "Lỗi: Khách hàng phải được vay nhờ điểm tín dụng cao (>=700)");
    }

    // Row 4: A=T, B=T, C=F, D=F -> Result = False (Chứng minh C & D độc lập - Cặp
    // với Row 2 & Row 3)
    @Test(description = "MCDC Row 4: TaiSanDocLap_KhongTaiSan (Đủ tuổi, Đủ thu nhập, Ko tài sản, Tín dụng THẤP)")
    public void testMCDC_TaiSanDocLap_KhongTaiSan() {
        boolean actual = BankLoanUtils.duDieuKienVay(25, 15_000_000, false, 600);
        Assert.assertFalse(actual, "Lỗi: Khách hàng KHÔNG được vay vì thiếu cả tài sản lẫn tín dụng!");
    }

    // Row 6: A=T, B=F, C=T, D=F -> Result = False (Chứng minh B độc lập - Cặp với
    // Row 2)
    @Test(description = "MCDC Row 6: ThuNhapDocLap_ThapHon10Tr (Thu nhập thấp)")
    public void testMCDC_ThuNhapDocLap_ThapHon10Tr() {
        boolean actual = BankLoanUtils.duDieuKienVay(25, 5_000_000, true, 600);
        Assert.assertFalse(actual, "Lỗi: Phải từ chối vì thu nhập không đủ 10 triệu!");
    }

    // Row 10: A=F, B=T, C=T, D=F -> Result = False (Chứng minh A độc lập - Cặp với
    // Row 2)
    @Test(description = "MCDC Row 10: TuoiDocLap_NhoHon22 (Trẻ tuổi, < 22)")
    public void testMCDC_TuoiDocLap_NhoHon22() {
        boolean actual = BankLoanUtils.duDieuKienVay(20, 15_000_000, true, 600);
        Assert.assertFalse(actual, "Lỗi: Phải từ chối vì chưa đủ 22 tuổi!");
    }

    // --- Bonus: Gộp tất cả 5 cases MC/DC sử dụng @DataProvider ---
    @DataProvider(name = "mcdcData")
    public Object[][] getMCDCData() {
        return new Object[][] {
                // Tuoi, ThuNhap, CoTaiSan, DiemTinDung, ExpectedResult
                { 25, 15_000_000, true, 600, true }, // Row 2
                { 25, 15_000_000, false, 750, true }, // Row 3
                { 25, 15_000_000, false, 600, false }, // Row 4
                { 25, 5_000_000, true, 600, false }, // Row 6
                { 20, 15_000_000, true, 600, false } // Row 10
        };
    }

    @Test(dataProvider = "mcdcData", description = "Test toàn bộ 5 MC/DC Cases thông qua DataProvider")
    public void testAllMCDCWithDataProvider(int tuoi, double thuNhap, boolean coTaiSan, int tinDung, boolean expected) {
        boolean actual = BankLoanUtils.duDieuKienVay(tuoi, thuNhap, coTaiSan, tinDung);
        Assert.assertEquals(actual, expected, "Lỗi logic tại tập dữ liệu MC/DC [Tuoi=" + tuoi + ", ThuNhap=" + thuNhap
                + ", TaiSan=" + coTaiSan + ", TinDung=" + tinDung + "]");
    }
}
