package dtm.bai4_2;

import dtm.bai4_1.ShippingUtils;
import org.testng.Assert;
import org.testng.annotations.Test;

/**
 * BAI 4.2 - Viet Test Case TestNG tu Basis Path
 * Su dung Assert.assertEquals co delta 0.01 cho so thuc.
 * Su dung Assert.assertThrows cho Exception.
 */
public class PhiShipBasisPathTest {

    @Test(description = "Path 1: Trong luong khong hop le (<= 0)")
    public void testPath1_InvalidWeight() {
        Assert.assertThrows(IllegalArgumentException.class,
                () -> ShippingUtils.tinhPhiShip(-1, "noi_thanh", false));
    }

    @Test(description = "Path 2: Noi thanh, <= 5kg, khong member")
    public void testPath2_NoiThanhNheKhongMember() {
        double expected = 15000;
        Assert.assertEquals(ShippingUtils.tinhPhiShip(3, "noi_thanh", false), expected, 0.01);
    }

    @Test(description = "Path 3: Noi thanh, > 5kg, khong member")
    public void testPath3_NoiThanhNangKhongMember() {
        double expected = 17000; // 15000 + (6-5) * 2000
        Assert.assertEquals(ShippingUtils.tinhPhiShip(6, "noi_thanh", false), expected, 0.01);
    }

    @Test(description = "Path 4: Ngoai thanh, <= 3kg, khong member")
    public void testPath4_NgoaiThanhNheKhongMember() {
        double expected = 25000;
        Assert.assertEquals(ShippingUtils.tinhPhiShip(2, "ngoai_thanh", false), expected, 0.01);
    }

    @Test(description = "Path 5: Ngoai thanh, > 3kg, khong member")
    public void testPath5_NgoaiThanhNangKhongMember() {
        double expected = 28000; // 25000 + (4-3) * 3000
        Assert.assertEquals(ShippingUtils.tinhPhiShip(4, "ngoai_thanh", false), expected, 0.01);
    }

    @Test(description = "Path 6: Tinh khac, <= 2kg, khong member")
    public void testPath6_TinhKhacNheKhongMember() {
        double expected = 50000;
        Assert.assertEquals(ShippingUtils.tinhPhiShip(1, "tinh_khac", false), expected, 0.01);
    }

    @Test(description = "Path 7: Tinh khac, > 2kg, khong member")
    public void testPath7_TinhKhacNangKhongMember() {
        double expected = 55000; // 50000 + (3-2) * 5000
        Assert.assertEquals(ShippingUtils.tinhPhiShip(3, "tinh_khac", false), expected, 0.01);
    }

    @Test(description = "Path 8: Noi thanh, > 5kg, LA member (giam 10%)")
    public void testPath8_NoiThanhNangCoMember() {
        // Truoc do (Path 3) la 17000, giam 10% = 17000 * 0.9 = 15300
        double expected = 15300;
        Assert.assertEquals(ShippingUtils.tinhPhiShip(6, "noi_thanh", true), expected, 0.01);
    }
}
