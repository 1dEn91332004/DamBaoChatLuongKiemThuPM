package dtm.bai1_1;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.Assert;
import org.testng.annotations.*;

/**
 * BAI 1.1 - KIEM THU TIEU DE TRANG WEB (saucedemo.com)
 *
 * Ky thuat: Selenium WebDriver + TestNG
 * Website: https://www.saucedemo.com
 *
 * TC_B1_001 - Kiem thu tieu de trang chu
 * TC_B1_002 - Kiem thu URL trang chu
 * TC_B1_003 - Kiem thu page source chua "Swag Labs"
 * TC_B1_004 - Kiem thu nut Login hien thi
 * TC_B1_005 - Kiem thu page source chua meta description "Sauce Labs"
 * TC_B1_006 - Kiem thu page source KHONG chua chuoi sai "Amazon"
 * TC_B1_007 - Kiem thu o nhap Username hien thi
 * TC_B1_008 - Kiem thu o nhap Password hien thi
 * TC_B1_009 - Kiem thu nut Login duoc kich hoat (enabled)
 */
public class TitleTest {

    WebDriver driver;

    @BeforeMethod
    public void setUp() {
        WebDriverManager.chromedriver().setup();
        ChromeOptions options = new ChromeOptions();
        options.addArguments("--start-maximized");
        options.addArguments("--disable-notifications");
        driver = new ChromeDriver(options);
        driver.get("https://www.saucedemo.com");
    }

    @AfterMethod
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }

    // TC_B1_001 - Kiem thu tieu de trang chu
    @Test(description = "TC_B1_001 - Kiem thu tieu de trang chu")
    public void testTitle() {
        String expectedTitle = "Swag Labs";
        String actualTitle = driver.getTitle();
        Assert.assertEquals(actualTitle, expectedTitle,
                "TC_B1_001 FAILED: Tieu de khong dung! Expected: ["
                        + expectedTitle + "] | Actual: [" + actualTitle + "]");
    }

    // TC_B1_002 - Kiem thu URL trang chu
    @Test(description = "TC_B1_002 - Kiem thu URL trang chu")
    public void testURL() {
        String actualUrl = driver.getCurrentUrl();
        Assert.assertTrue(actualUrl.contains("saucedemo"),
                "TC_B1_002 FAILED: URL khong hop le! Actual URL: " + actualUrl);
    }

    // TC_B1_003 - Kiem thu page source chua ten thuong hieu
    @Test(description = "TC_B1_003 - Kiem thu page source chua 'Swag Labs'")
    public void testPageSourceContainsBrandName() {
        String pageSource = driver.getPageSource();
        Assert.assertTrue(pageSource.contains("Swag Labs"),
                "TC_B1_003 FAILED: Page source khong chua 'Swag Labs'");
    }

    // TC_B1_004 - Kiem thu nut Login hien thi
    @Test(description = "TC_B1_004 - Kiem thu nut Login co hien thi hay khong")
    public void testLoginButtonIsDisplayed() {
        org.openqa.selenium.WebElement loginBtn = driver.findElement(org.openqa.selenium.By.id("login-button"));
        Assert.assertTrue(loginBtn.isDisplayed(),
                "TC_B1_004 FAILED: Nut Login khong hien thi!");
    }

    // TC_B1_005 - Kiem thu page source chua meta description
    @Test(description = "TC_B1_005 - Kiem thu page source chua meta description 'Sauce Labs'")
    public void testPageSourceContainsMetaDescription() {
        String pageSource = driver.getPageSource();
        Assert.assertTrue(pageSource.contains("Sauce Labs"),
                "TC_B1_005 FAILED: Page source khong chua 'Sauce Labs'");
    }

    // TC_B1_006 - Kiem thu page source KHONG chua chuoi sai
    @Test(description = "TC_B1_006 - Kiem thu page source khong chua 'Amazon'")
    public void testPageSourceNotContainsWrongBrand() {
        String pageSource = driver.getPageSource();
        Assert.assertFalse(pageSource.contains("Amazon"),
                "TC_B1_006 FAILED: Page source bi loi - chua chuoi sai 'Amazon'");
    }

    // TC_B1_007 - Kiem thu o nhap Username hien thi
    @Test(description = "TC_B1_007 - Kiem thu o nhap Username hien thi tren form")
    public void testUsernameFieldIsDisplayed() {
        org.openqa.selenium.WebElement usernameField = driver.findElement(org.openqa.selenium.By.id("user-name"));
        Assert.assertTrue(usernameField.isDisplayed(),
                "TC_B1_007 FAILED: O nhap Username khong hien thi!");
    }

    // TC_B1_008 - Kiem thu o nhap Password hien thi
    @Test(description = "TC_B1_008 - Kiem thu o nhap Password hien thi tren form")
    public void testPasswordFieldIsDisplayed() {
        org.openqa.selenium.WebElement passwordField = driver.findElement(org.openqa.selenium.By.id("password"));
        Assert.assertTrue(passwordField.isDisplayed(),
                "TC_B1_008 FAILED: O nhap Password khong hien thi!");
    }

    // TC_B1_009 - Kiem thu nut Login duoc kich hoat (enabled)
    @Test(description = "TC_B1_009 - Kiem thu nut Login duoc kich hoat (khong bi disabled)")
    public void testLoginButtonIsEnabled() {
        org.openqa.selenium.WebElement loginBtn = driver.findElement(org.openqa.selenium.By.id("login-button"));
        Assert.assertTrue(loginBtn.isEnabled(),
                "TC_B1_009 FAILED: Nut Login bi disabled!");
    }
}
