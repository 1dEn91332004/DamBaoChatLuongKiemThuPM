package dtm.bai2_1;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.*;

import java.time.Duration;

/**
 * BAI 2.1 - CartTest
 * Nhom: smoke (testAddToCart)
 * regression (tat ca)
 *
 * Truoc khi test gio hang: can dang nhap thanh cong truoc
 */
public class CartTest {

    private WebDriver driver;
    private WebDriverWait wait;

    private static final By USERNAME_INPUT = By.id("user-name");
    private static final By PASSWORD_INPUT = By.id("password");
    private static final By LOGIN_BUTTON = By.id("login-button");
    private static final By ADD_TO_CART_BTN = By.id("add-to-cart-sauce-labs-backpack");
    private static final By CART_BADGE = By.className("shopping_cart_badge");
    private static final By REMOVE_BTN = By.id("remove-sauce-labs-backpack");

    @BeforeMethod(alwaysRun = true)
    public void setUp() {
        WebDriverManager.chromedriver().setup();
        ChromeOptions options = new ChromeOptions();
        options.addArguments("--start-maximized");
        driver = new ChromeDriver(options);
        wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        // Dang nhap truoc khi test gio hang
        driver.get("https://www.saucedemo.com");
        wait.until(ExpectedConditions.visibilityOfElementLocated(USERNAME_INPUT))
                .sendKeys("standard_user");
        driver.findElement(PASSWORD_INPUT).sendKeys("secret_sauce");
        driver.findElement(LOGIN_BUTTON).click();
        wait.until(ExpectedConditions.urlContains("inventory.html"));
    }

    @AfterMethod(alwaysRun = true)
    public void tearDown() {
        if (driver != null)
            driver.quit();
    }

    // SMOKE + REGRESSION: Them san pham vao gio hang
    @Test(groups = { "smoke", "regression" }, description = "TC_C1 - Them san pham Backpack vao gio hang")
    public void testAddToCart() {
        wait.until(ExpectedConditions.elementToBeClickable(ADD_TO_CART_BTN)).click();
        WebElement badge = wait.until(ExpectedConditions.visibilityOfElementLocated(CART_BADGE));
        Assert.assertEquals(badge.getText(), "1",
                "TC_C1 FAILED: So luong gio hang phai la 1. Actual: " + badge.getText());
    }

    // REGRESSION: Kiem tra so hieu hien tren icon gio hang
    @Test(groups = { "regression" }, description = "TC_C2 - So hieu gio hang tang dung sau khi them")
    public void testCartBadge() {
        // Them 1 san pham
        wait.until(ExpectedConditions.elementToBeClickable(ADD_TO_CART_BTN)).click();
        WebElement badge = wait.until(ExpectedConditions.visibilityOfElementLocated(CART_BADGE));
        int count = Integer.parseInt(badge.getText());
        Assert.assertEquals(count, 1,
                "TC_C2 FAILED: So luong gio hang phai la 1. Actual: " + count);
    }

    // REGRESSION: Xoa san pham khoi gio hang
    @Test(groups = { "regression" }, description = "TC_C3 - Xoa san pham khoi gio hang")
    public void testRemoveFromCart() {
        // Them truoc roi xoa
        wait.until(ExpectedConditions.elementToBeClickable(ADD_TO_CART_BTN)).click();
        wait.until(ExpectedConditions.visibilityOfElementLocated(CART_BADGE));
        // Click Remove
        wait.until(ExpectedConditions.elementToBeClickable(REMOVE_BTN)).click();
        // Gio hang phai rong (badge bien mat)
        boolean badgeGone = wait.until(ExpectedConditions.invisibilityOfElementLocated(CART_BADGE));
        Assert.assertTrue(badgeGone,
                "TC_C3 FAILED: Badge gio hang van con sau khi xoa san pham");
    }
}
