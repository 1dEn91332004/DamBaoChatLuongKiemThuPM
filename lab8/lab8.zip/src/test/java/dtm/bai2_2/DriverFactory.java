package dtm.bai2_2;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;

/**
 * BAI 2.2 - DriverFactory su dung ThreadLocal<WebDriver>
 *
 * Muc dich: Dam bao moi thread co WebDriver RIENG BIET khi chay song song.
 *
 * TUYET DOI KHONG dung bien static WebDriver:
 * private static WebDriver driver; // SAI - gay race condition
 *
 * Thay vao do dung ThreadLocal:
 * ThreadLocal<WebDriver> tlDriver; // DUNG - moi thread ban sao rieng
 */
public class DriverFactory {

    // ThreadLocal: moi thread co bien driver rieng biet
    private static ThreadLocal<WebDriver> tlDriver = new ThreadLocal<>();

    /**
     * Khoi tao WebDriver cho thread hien tai.
     * 
     * @param browser "chrome" hoac "firefox"
     */
    public static void initDriver(String browser) {
        WebDriver driver;
        switch (browser.toLowerCase()) {
            case "firefox":
                WebDriverManager.firefoxdriver().setup();
                driver = new FirefoxDriver();
                break;
            default: // chrome
                WebDriverManager.chromedriver().setup();
                ChromeOptions options = new ChromeOptions();
                options.addArguments("--start-maximized");
                options.addArguments("--disable-notifications");
                driver = new ChromeDriver(options);
                break;
        }
        driver.manage().window().maximize();
        tlDriver.set(driver); // Luu driver vao ThreadLocal cua thread hien tai
    }

    /**
     * Lay WebDriver cua thread hien tai.
     */
    public static WebDriver getDriver() {
        return tlDriver.get();
    }

    /**
     * Dong WebDriver cua thread hien tai va xoa khoi ThreadLocal.
     * Rat quan trong: tranh memory leak!
     */
    public static void quitDriver() {
        if (tlDriver.get() != null) {
            tlDriver.get().quit();
            tlDriver.remove(); // Bat buoc goi remove() de tranh memory leak
        }
    }
}
