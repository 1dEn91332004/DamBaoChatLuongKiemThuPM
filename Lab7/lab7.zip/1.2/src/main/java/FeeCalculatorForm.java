import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.*;
import java.awt.*;
import java.awt.event.*;
import java.text.NumberFormat;
import java.util.Locale;

/**
 * Bài 1.2 – Bảng Quyết Định – Chính Sách Phí Dịch Vụ Ngân Hàng VietBank
 * LAB 7 | Kiểm Thử Hộp Đen – Black-Box Testing
 *
 * ĐIỀU KIỆN:
 * C1: Khách hàng VIP (số dư TB tháng >= 50 triệu)?
 * C2: Giao dịch trong giờ hành chính (Mon–Fri 8:00–17:00)?
 * C3: Chuyển tiền cùng ngân hàng (nội bộ)?
 * C4: Số tiền giao dịch > 500 triệu đồng?
 *
 * HÀNH ĐỘNG:
 * A1: Miễn 100% phí
 * A2: Phí 3.300đ/giao dịch
 * A3: Phí 8.800đ/giao dịch
 * A4: Phí 11.000đ/giao dịch
 * A5: Phí 16.500đ/giao dịch + OTP bổ sung
 *
 * QUY TẮC (8 quy tắc):
 * R1: VIP + cùng NH → A1 (bất kể giờ)
 * R2: VIP + khác NH + giờ HC + ≤500tr → A2
 * R3: VIP + khác NH + ngoài giờ + ≤500tr → A3
 * R4: Không VIP + cùng NH + giờ HC + ≤500tr → A2
 * R5: Không VIP + cùng NH + ngoài giờ + ≤500tr → A3
 * R6: Không VIP + khác NH + giờ HC + ≤500tr → A4
 * R7: Không VIP + khác NH + ngoài giờ + ≤500tr → A5
 * R8: Bất kỳ giao dịch > 500 triệu → phí hiện tại + OTP bổ sung
 */
public class FeeCalculatorForm extends JFrame {

    // ── Màu sắc theme ngân hàng ──
    private static final Color PRIMARY = new Color(0x0D47A1);
    private static final Color SECONDARY = new Color(0x1565C0);
    private static final Color ACCENT = new Color(0xFFB300);
    private static final Color SUCCESS = new Color(0x2E7D32);
    private static final Color DANGER = new Color(0xB71C1C);
    private static final Color BG = new Color(0xECEFF1);
    private static final Color CARD = Color.WHITE;
    private static final Color TEXT = new Color(0x212121);
    private static final Color MUTED = new Color(0x607D8B);

    // ── UI Components ──
    private JCheckBox chkVIP, chkGioHC, chkCungNH, chkLonHon500;
    private JLabel lblResult, lblRule, lblFee, lblOTP;
    private JPanel pnlResult;

    public FeeCalculatorForm() {
        setTitle("VietBank – Bảng Quyết Định Phí Chuyển Tiền | LAB 7");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(900, 720);
        setLocationRelativeTo(null);
        setResizable(false);
        getContentPane().setBackground(BG);
        initUI();
    }

    // ──────────────────────────────────────────────────────────────────────────
    private void initUI() {
        setLayout(new BorderLayout(0, 0));

        // ── Header ──
        add(buildHeader(), BorderLayout.NORTH);

        // ── Center: Decision Table + Input Panel ──
        JPanel center = new JPanel(new BorderLayout(12, 12));
        center.setBackground(BG);
        center.setBorder(new EmptyBorder(16, 16, 16, 16));

        center.add(buildDecisionTable(), BorderLayout.CENTER);
        center.add(buildInputPanel(), BorderLayout.EAST);

        add(center, BorderLayout.CENTER);

        // ── Footer ──
        add(buildFooter(), BorderLayout.SOUTH);
    }

    // ── Header ──────────────────────────────────────────────────────────────
    private JPanel buildHeader() {
        JPanel p = new JPanel(new BorderLayout());
        p.setBackground(PRIMARY);
        p.setBorder(new EmptyBorder(16, 24, 16, 24));

        JLabel bank = new JLabel("🏦 VietBank");
        bank.setFont(new Font("Segoe UI", Font.BOLD, 24));
        bank.setForeground(Color.WHITE);

        JLabel title = new JLabel("Bảng Quyết Định – Chính Sách Phí Chuyển Tiền Online");
        title.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        title.setForeground(new Color(0xBBDEFB));

        JPanel left = new JPanel(new GridLayout(2, 1, 0, 2));
        left.setOpaque(false);
        left.add(bank);
        left.add(title);
        p.add(left, BorderLayout.WEST);

        JLabel lab = new JLabel("LAB 7 – Bài 1.2");
        lab.setFont(new Font("Segoe UI", Font.BOLD, 13));
        lab.setForeground(ACCENT);
        p.add(lab, BorderLayout.EAST);
        return p;
    }

    // ── Bảng Quyết Định ─────────────────────────────────────────────────────
    private JPanel buildDecisionTable() {
        JPanel p = new JPanel(new BorderLayout(0, 8));
        p.setBackground(CARD);
        p.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(0xCFD8DC), 1, true),
                new EmptyBorder(12, 12, 12, 12)));

        JLabel title = new JLabel("📋 Bảng Quyết Định (Decision Table)");
        title.setFont(new Font("Segoe UI", Font.BOLD, 14));
        title.setForeground(PRIMARY);
        p.add(title, BorderLayout.NORTH);

        // --- Dữ liệu bảng ---
        // Y=Có, N=Không, -=Không quan tâm
        String[] cols = { "Điều kiện / Hành động", "R1", "R2", "R3", "R4", "R5", "R6", "R7", "R8" };
        Object[][] data = {
                { "C1: Khách hàng VIP (≥50tr/tháng)", "Y", "Y", "Y", "N", "N", "N", "N", "–" },
                { "C2: Trong giờ hành chính", "–", "Y", "N", "Y", "N", "Y", "N", "–" },
                { "C3: Cùng ngân hàng (nội bộ)", "Y", "N", "N", "Y", "Y", "N", "N", "–" },
                { "C4: Số tiền > 500 triệu", "–", "N", "N", "N", "N", "N", "N", "Y" },
                { "─────────────────────────────────", "──", "──", "──", "──", "──", "──", "──", "──" },
                { "A1: Miễn 100% phí", "✔", "", "", "", "", "", "", "" },
                { "A2: Phí 3.300đ", "", "✔", "", "✔", "", "", "", "" },
                { "A3: Phí 8.800đ", "", "", "✔", "", "✔", "", "", "" },
                { "A4: Phí 11.000đ", "", "", "", "", "", "✔", "", "" },
                { "A5: Phí 16.500đ", "", "", "", "", "", "", "✔", "" },
                { "OTP xác thực bổ sung", "", "", "", "", "", "", "", "✔" },
        };

        DefaultTableModel model = new DefaultTableModel(data, cols) {
            public boolean isCellEditable(int r, int c) {
                return false;
            }
        };

        JTable table = new JTable(model);
        table.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        table.setRowHeight(26);
        table.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 12));
        table.getTableHeader().setBackground(SECONDARY);
        table.getTableHeader().setForeground(Color.WHITE);
        table.setGridColor(new Color(0xE0E0E0));
        table.setSelectionBackground(new Color(0xBBDEFB));

        // Renderer tô màu
        DefaultTableCellRenderer renderer = new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable t, Object v,
                    boolean sel, boolean focus, int row, int col) {
                Component c = super.getTableCellRendererComponent(t, v, sel, focus, row, col);
                String val = v == null ? "" : v.toString();

                if (row == 4) { // separator
                    c.setBackground(new Color(0xECEFF1));
                    c.setForeground(MUTED);
                    ((JLabel) c).setFont(new Font("Segoe UI", Font.PLAIN, 9));
                } else if (col == 0) {
                    c.setBackground(new Color(0xE3F2FD));
                    c.setForeground(TEXT);
                    ((JLabel) c).setFont(new Font("Segoe UI", Font.BOLD, 11));
                } else if ("✔".equals(val)) {
                    c.setBackground(new Color(0xE8F5E9));
                    c.setForeground(SUCCESS);
                    ((JLabel) c).setHorizontalAlignment(SwingConstants.CENTER);
                    ((JLabel) c).setFont(new Font("Segoe UI", Font.BOLD, 14));
                } else if ("Y".equals(val)) {
                    c.setBackground(new Color(0xFFF8E1));
                    c.setForeground(new Color(0xE65100));
                    ((JLabel) c).setHorizontalAlignment(SwingConstants.CENTER);
                } else if ("N".equals(val)) {
                    c.setBackground(new Color(0xFCE4EC));
                    c.setForeground(DANGER);
                    ((JLabel) c).setHorizontalAlignment(SwingConstants.CENTER);
                } else if ("–".equals(val)) {
                    c.setBackground(new Color(0xF5F5F5));
                    c.setForeground(MUTED);
                    ((JLabel) c).setHorizontalAlignment(SwingConstants.CENTER);
                } else {
                    c.setBackground(CARD);
                    ((JLabel) c).setHorizontalAlignment(SwingConstants.CENTER);
                }
                if (!sel && row != 4 && col != 0
                        && !"Y".equals(val) && !"N".equals(val)
                        && !"–".equals(val) && !"✔".equals(val)) {
                    c.setBackground(new Color(0xFAFAFA));
                }
                return c;
            }
        };
        for (int i = 0; i < table.getColumnCount(); i++)
            table.getColumnModel().getColumn(i).setCellRenderer(renderer);

        // Column widths
        table.getColumnModel().getColumn(0).setPreferredWidth(240);
        for (int i = 1; i <= 8; i++)
            table.getColumnModel().getColumn(i).setPreferredWidth(50);

        p.add(new JScrollPane(table), BorderLayout.CENTER);

        // Chú thích
        JLabel note = new JLabel("  Y = Có  |  N = Không  |  – = Không quan tâm  |  ✔ = Áp dụng");
        note.setFont(new Font("Segoe UI", Font.ITALIC, 11));
        note.setForeground(MUTED);
        p.add(note, BorderLayout.SOUTH);
        return p;
    }

    // ── Panel Nhập Điều Kiện ────────────────────────────────────────────────
    private JPanel buildInputPanel() {
        JPanel outer = new JPanel(new BorderLayout(0, 10));
        outer.setBackground(BG);
        outer.setPreferredSize(new Dimension(270, 0));

        // -- Card điều kiện --
        JPanel card = new JPanel();
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setBackground(CARD);
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(0xCFD8DC), 1, true),
                new EmptyBorder(14, 14, 14, 14)));

        JLabel lTitle = new JLabel("⚙ Nhập Điều Kiện");
        lTitle.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lTitle.setForeground(PRIMARY);
        lTitle.setAlignmentX(Component.LEFT_ALIGNMENT);
        card.add(lTitle);
        card.add(Box.createVerticalStrut(12));

        chkVIP = makeCheck("C1: Khách hàng VIP (≥ 50tr/tháng)");
        chkGioHC = makeCheck("C2: Trong giờ hành chính (T2–T6, 8–17h)");
        chkCungNH = makeCheck("C3: Chuyển cùng ngân hàng (nội bộ)");
        chkLonHon500 = makeCheck("C4: Số tiền > 500 triệu đồng");

        card.add(chkVIP);
        card.add(Box.createVerticalStrut(8));
        card.add(chkGioHC);
        card.add(Box.createVerticalStrut(8));
        card.add(chkCungNH);
        card.add(Box.createVerticalStrut(8));
        card.add(chkLonHon500);
        card.add(Box.createVerticalStrut(16));

        JButton btnCalc = new JButton("Tính Phí →");
        btnCalc.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnCalc.setBackground(PRIMARY);
        btnCalc.setForeground(Color.WHITE);
        btnCalc.setFocusPainted(false);
        btnCalc.setBorder(new EmptyBorder(10, 20, 10, 20));
        btnCalc.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btnCalc.setAlignmentX(Component.LEFT_ALIGNMENT);
        btnCalc.setMaximumSize(new Dimension(Integer.MAX_VALUE, 42));
        btnCalc.addActionListener(e -> calculate());
        card.add(btnCalc);

        JButton btnReset = new JButton("Đặt lại");
        btnReset.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        btnReset.setBorderPainted(false);
        btnReset.setContentAreaFilled(false);
        btnReset.setForeground(MUTED);
        btnReset.setAlignmentX(Component.LEFT_ALIGNMENT);
        btnReset.addActionListener(e -> {
            chkVIP.setSelected(false);
            chkGioHC.setSelected(false);
            chkCungNH.setSelected(false);
            chkLonHon500.setSelected(false);
            pnlResult.setVisible(false);
        });
        card.add(Box.createVerticalStrut(4));
        card.add(btnReset);

        // -- Card kết quả --
        pnlResult = new JPanel();
        pnlResult.setLayout(new BoxLayout(pnlResult, BoxLayout.Y_AXIS));
        pnlResult.setBackground(new Color(0xE8F5E9));
        pnlResult.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(0x4CAF50), 2, true),
                new EmptyBorder(14, 14, 14, 14)));
        pnlResult.setVisible(false);

        JLabel lRes = new JLabel("📊 Kết Quả");
        lRes.setFont(new Font("Segoe UI", Font.BOLD, 13));
        lRes.setForeground(SUCCESS);
        lRes.setAlignmentX(Component.LEFT_ALIGNMENT);

        lblRule = new JLabel();
        lblRule.setFont(new Font("Segoe UI", Font.BOLD, 13));
        lblRule.setForeground(SECONDARY);
        lblRule.setAlignmentX(Component.LEFT_ALIGNMENT);

        lblFee = new JLabel();
        lblFee.setFont(new Font("Segoe UI", Font.BOLD, 22));
        lblFee.setForeground(DANGER);
        lblFee.setAlignmentX(Component.LEFT_ALIGNMENT);

        lblResult = new JLabel();
        lblResult.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        lblResult.setForeground(TEXT);
        lblResult.setAlignmentX(Component.LEFT_ALIGNMENT);

        lblOTP = new JLabel("🔐 Yêu cầu OTP xác thực bổ sung!");
        lblOTP.setFont(new Font("Segoe UI", Font.BOLD, 12));
        lblOTP.setForeground(new Color(0xE65100));
        lblOTP.setAlignmentX(Component.LEFT_ALIGNMENT);

        pnlResult.add(lRes);
        pnlResult.add(Box.createVerticalStrut(8));
        pnlResult.add(lblRule);
        pnlResult.add(Box.createVerticalStrut(4));
        pnlResult.add(lblFee);
        pnlResult.add(Box.createVerticalStrut(4));
        pnlResult.add(lblResult);
        pnlResult.add(Box.createVerticalStrut(6));
        pnlResult.add(lblOTP);

        outer.add(card, BorderLayout.NORTH);
        outer.add(pnlResult, BorderLayout.CENTER);
        return outer;
    }

    // ── Logic Bảng Quyết Định ───────────────────────────────────────────────
    private void calculate() {
        boolean vip = chkVIP.isSelected();
        boolean gioHC = chkGioHC.isSelected();
        boolean cungNH = chkCungNH.isSelected();
        boolean lon500 = chkLonHon500.isSelected();

        String rule, feeText, detail;
        boolean needOTP = lon500; // R8: >500 triệu luôn cần OTP

        if (vip && cungNH) {
            // R1: VIP + cùng NH → Miễn phí (bất kể giờ, bất kể số tiền)
            rule = "Quy tắc R1";
            feeText = "MIỄN PHÍ (0đ)";
            detail = "VIP + Cùng ngân hàng → Miễn 100% phí";
            lblFee.setForeground(SUCCESS);
        } else if (vip && !cungNH && gioHC) {
            // R2: VIP + khác NH + giờ HC
            rule = "Quy tắc R2";
            feeText = "3.300đ / giao dịch";
            detail = "VIP + Khác ngân hàng + Giờ hành chính";
            lblFee.setForeground(DANGER);
        } else if (vip && !cungNH && !gioHC) {
            // R3: VIP + khác NH + ngoài giờ
            rule = "Quy tắc R3";
            feeText = "8.800đ / giao dịch";
            detail = "VIP + Khác ngân hàng + Ngoài giờ hành chính";
            lblFee.setForeground(DANGER);
        } else if (!vip && cungNH && gioHC) {
            // R4: Không VIP + cùng NH + giờ HC
            rule = "Quy tắc R4";
            feeText = "3.300đ / giao dịch";
            detail = "Không VIP + Cùng ngân hàng + Giờ hành chính";
            lblFee.setForeground(DANGER);
        } else if (!vip && cungNH && !gioHC) {
            // R5: Không VIP + cùng NH + ngoài giờ
            rule = "Quy tắc R5";
            feeText = "8.800đ / giao dịch";
            detail = "Không VIP + Cùng ngân hàng + Ngoài giờ hành chính";
            lblFee.setForeground(DANGER);
        } else if (!vip && !cungNH && gioHC) {
            // R6: Không VIP + khác NH + giờ HC
            rule = "Quy tắc R6";
            feeText = "11.000đ / giao dịch";
            detail = "Không VIP + Khác ngân hàng + Giờ hành chính";
            lblFee.setForeground(DANGER);
        } else {
            // R7: Không VIP + khác NH + ngoài giờ
            rule = "Quy tắc R7";
            feeText = "16.500đ / giao dịch";
            detail = "Không VIP + Khác ngân hàng + Ngoài giờ hành chính";
            lblFee.setForeground(DANGER);
        }

        // R8 modifier
        if (lon500) {
            rule += " + R8 (>500 triệu)";
            feeText += " + OTP";
        }

        lblRule.setText("🔖 " + rule);
        lblFee.setText(feeText);
        lblResult.setText("<html><i>" + detail + "</i></html>");
        lblOTP.setVisible(needOTP);

        pnlResult.setBackground(needOTP ? new Color(0xFFF8E1) : new Color(0xE8F5E9));
        pnlResult.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(needOTP
                        ? new Color(0xFFB300)
                        : new Color(0x4CAF50), 2, true),
                new EmptyBorder(14, 14, 14, 14)));

        pnlResult.setVisible(true);
        pnlResult.revalidate();
        pnlResult.repaint();
    }

    // ── Footer ──────────────────────────────────────────────────────────────
    private JPanel buildFooter() {
        JPanel p = new JPanel(new BorderLayout());
        p.setBackground(new Color(0x37474F));
        p.setBorder(new EmptyBorder(8, 16, 8, 16));
        JLabel l = new JLabel("LAB 7 | Kiểm Thử Hộp Đen – Bảng Quyết Định | VietBank Fee Policy");
        l.setFont(new Font("Segoe UI", Font.ITALIC, 11));
        l.setForeground(new Color(0xB0BEC5));
        p.add(l, BorderLayout.WEST);
        JLabel r = new JLabel("Huynh Kòm – Kiểm Thử Phần Mềm");
        r.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        r.setForeground(new Color(0xB0BEC5));
        p.add(r, BorderLayout.EAST);
        return p;
    }

    private JCheckBox makeCheck(String text) {
        JCheckBox chk = new JCheckBox(text);
        chk.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        chk.setBackground(CARD);
        chk.setForeground(TEXT);
        chk.setAlignmentX(Component.LEFT_ALIGNMENT);
        return chk;
    }

    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception ignored) {
        }
        SwingUtilities.invokeLater(() -> new FeeCalculatorForm().setVisible(true));
    }
}
