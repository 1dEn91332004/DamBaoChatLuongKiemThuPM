import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.HashSet;
import java.util.Set;
import java.util.regex.Pattern;

/**
 * Form Đăng Ký Tài Khoản – ShopVN.vn
 * Lab 7 – Kiểm Thử Hộp Đen (Black-Box Testing)
 */
public class RegisterForm extends JFrame {

    // ──────────────────────────────────────────────────────────────────────────
    // Giả lập CSDL
    // ──────────────────────────────────────────────────────────────────────────
    private static final Set<String> EXISTING_EMAILS = new HashSet<>();
    private static final Set<String> EXISTING_USERNAMES = new HashSet<>();
    private static final Set<String> VALID_REFERRAL_CODES = new HashSet<>();

    static {
        EXISTING_EMAILS.add("test@example.com");
        EXISTING_EMAILS.add("admin@shopvn.vn");
        EXISTING_USERNAMES.add("admin");
        EXISTING_USERNAMES.add("shopvn");
        VALID_REFERRAL_CODES.add("REF00001");
        VALID_REFERRAL_CODES.add("PROMO123");
        VALID_REFERRAL_CODES.add("ABCD1234");
    }

    // ──────────────────────────────────────────────────────────────────────────
    // REGEX
    // ──────────────────────────────────────────────────────────────────────────
    private static final Pattern FULLNAME_PATTERN =
            Pattern.compile("^[\\p{L} ]{2,50}$");
    private static final Pattern USERNAME_PATTERN =
            Pattern.compile("^[a-z][a-z0-9_]{4,19}$");
    private static final Pattern EMAIL_PATTERN =
            Pattern.compile("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$");
    private static final Pattern PHONE_PATTERN =
            Pattern.compile("^0\\d{9}$");
    private static final Pattern PASSWORD_PATTERN =
            Pattern.compile("^(?=.*[A-Z])(?=.*[a-z])(?=.*\\d)(?=.*[!@#$%])[A-Za-z\\d!@#$%]{8,32}$");
    private static final Pattern REFERRAL_PATTERN =
            Pattern.compile("^[A-Z0-9]{8}$");
    private static final DateTimeFormatter DATE_FORMATTER =
            DateTimeFormatter.ofPattern("dd/MM/yyyy");

    // ──────────────────────────────────────────────────────────────────────────
    // UI Components
    // ──────────────────────────────────────────────────────────────────────────
    private JTextField txtFullName, txtUsername, txtEmail, txtPhone, txtBirthday, txtReferral;
    private JPasswordField txtPassword, txtConfirmPassword;
    private JRadioButton rbMale, rbFemale, rbOther;
    private ButtonGroup genderGroup;
    private JCheckBox chkAgree;
    private JButton btnRegister, btnLogin;
    private JLabel lblFullNameError, lblUsernameError, lblEmailError, lblPhoneError,
                   lblPasswordError, lblConfirmError, lblBirthdayError, lblReferralError,
                   lblAgreeError;

    // Màu sắc
    private static final Color PRIMARY   = new Color(0x1565C0);
    private static final Color SUCCESS   = new Color(0x2E7D32);
    private static final Color DANGER    = new Color(0xC62828);
    private static final Color BG_COLOR  = new Color(0xF5F7FA);
    private static final Color CARD_BG   = Color.WHITE;
    private static final Color BORDER_C  = new Color(0xCFD8DC);
    private static final Color LABEL_FG  = new Color(0x37474F);
    private static final Color REQUIRED  = new Color(0xE53935);

    public RegisterForm() {
        setTitle("Đăng Ký Tài Khoản – ShopVN.vn");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(650, 900);
        setLocationRelativeTo(null);
        setResizable(false);
        getContentPane().setBackground(BG_COLOR);
        initUI();
        addListeners();
    }

    // ──────────────────────────────────────────────────────────────────────────
    // Khởi tạo UI
    // ──────────────────────────────────────────────────────────────────────────
    private void initUI() {
        setLayout(new BorderLayout());

        // ── Header ──
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(PRIMARY);
        header.setBorder(new EmptyBorder(18, 24, 18, 24));
        JLabel logo = new JLabel("🛒 ShopVN.vn");
        logo.setFont(new Font("Segoe UI", Font.BOLD, 22));
        logo.setForeground(Color.WHITE);
        JLabel subTitle = new JLabel("Tạo tài khoản mua sắm miễn phí");
        subTitle.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        subTitle.setForeground(new Color(0xBBDEFB));
        JPanel headerText = new JPanel(new GridLayout(2, 1));
        headerText.setOpaque(false);
        headerText.add(logo);
        headerText.add(subTitle);
        header.add(headerText, BorderLayout.WEST);
        add(header, BorderLayout.NORTH);

        // ── Form Panel (scroll) ──
        JPanel form = new JPanel();
        form.setLayout(new BoxLayout(form, BoxLayout.Y_AXIS));
        form.setBackground(BG_COLOR);
        form.setBorder(new EmptyBorder(20, 40, 20, 40));

        // Các trường
        txtFullName      = createTextField(50);
        txtUsername      = createTextField(20);
        txtEmail         = createTextField(100);
        txtPhone         = createTextField(10);
        txtPassword      = createPasswordField();
        txtConfirmPassword = createPasswordField();
        txtBirthday      = createTextField(10);
        txtBirthday.setText("dd/mm/yyyy");
        txtBirthday.setForeground(Color.GRAY);
        txtReferral      = createTextField(8);

        lblFullNameError   = createErrorLabel();
        lblUsernameError   = createErrorLabel();
        lblEmailError      = createErrorLabel();
        lblPhoneError      = createErrorLabel();
        lblPasswordError   = createErrorLabel();
        lblConfirmError    = createErrorLabel();
        lblBirthdayError   = createErrorLabel();
        lblReferralError   = createErrorLabel();
        lblAgreeError      = createErrorLabel();

        // Gender
        rbMale   = new JRadioButton("Nam");
        rbFemale = new JRadioButton("Nữ");
        rbOther  = new JRadioButton("Không muốn tiết lộ");
        rbOther.setSelected(true);
        genderGroup = new ButtonGroup();
        genderGroup.add(rbMale);
        genderGroup.add(rbFemale);
        genderGroup.add(rbOther);
        styleRadio(rbMale); styleRadio(rbFemale); styleRadio(rbOther);

        // Agree
        chkAgree = new JCheckBox("Tôi đồng ý với ");
        chkAgree.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        chkAgree.setBackground(BG_COLOR);
        chkAgree.setForeground(LABEL_FG);
        JButton btnViewTerms = new JButton("Xem Điều khoản");
        btnViewTerms.setFont(new Font("Segoe UI", Font.BOLD, 13));
        btnViewTerms.setBorderPainted(false);
        btnViewTerms.setContentAreaFilled(false);
        btnViewTerms.setForeground(PRIMARY);
        btnViewTerms.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btnViewTerms.addActionListener(e -> showTermsPopup());

        // Buttons
        btnRegister = new JButton("Đăng Ký");
        btnRegister.setFont(new Font("Segoe UI", Font.BOLD, 15));
        btnRegister.setBackground(PRIMARY);
        btnRegister.setForeground(Color.WHITE);
        btnRegister.setFocusPainted(false);
        btnRegister.setBorder(new EmptyBorder(12, 30, 12, 30));
        btnRegister.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btnRegister.setEnabled(false);

        btnLogin = new JButton("Đã có tài khoản? Đăng nhập");
        btnLogin.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        btnLogin.setBorderPainted(false);
        btnLogin.setContentAreaFilled(false);
        btnLogin.setForeground(PRIMARY);
        btnLogin.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

        // ── Thêm các trường vào form ──
        form.add(buildField("Họ và tên", true, txtFullName, lblFullNameError, "2–50 ký tự, chỉ chữ cái và dấu cách"));
        form.add(Box.createVerticalStrut(6));
        form.add(buildField("Tên đăng nhập", true, txtUsername, lblUsernameError, "5–20 ký tự, chữ thường/số/gạch dưới, bắt đầu bằng chữ cái"));
        form.add(Box.createVerticalStrut(6));
        form.add(buildField("Email", true, txtEmail, lblEmailError, "Định dạng email hợp lệ, chưa đăng ký"));
        form.add(Box.createVerticalStrut(6));
        form.add(buildField("Số điện thoại", true, txtPhone, lblPhoneError, "Bắt đầu bằng 0, gồm 10 chữ số"));
        form.add(Box.createVerticalStrut(6));
        form.add(buildField("Mật khẩu", true, txtPassword, lblPasswordError, "8–32 ký tự, có chữ hoa, chữ thường, số, ký tự đặc biệt (!@#$%)"));
        form.add(Box.createVerticalStrut(6));
        form.add(buildField("Xác nhận mật khẩu", true, txtConfirmPassword, lblConfirmError, "Phải trùng khớp với Mật khẩu"));
        form.add(Box.createVerticalStrut(6));
        form.add(buildField("Ngày sinh", false, txtBirthday, lblBirthdayError, "dd/mm/yyyy, từ 16–100 tuổi (không bắt buộc)"));
        form.add(Box.createVerticalStrut(6));

        // Gender row
        JPanel genderRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        genderRow.setBackground(BG_COLOR);
        JLabel genderLabel = new JLabel("Giới tính");
        genderLabel.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        genderLabel.setForeground(LABEL_FG);
        genderLabel.setPreferredSize(new Dimension(160, 24));
        genderRow.add(genderLabel);
        genderRow.add(rbMale); genderRow.add(rbFemale); genderRow.add(rbOther);
        genderRow.setAlignmentX(Component.LEFT_ALIGNMENT);
        genderRow.setMaximumSize(new Dimension(Integer.MAX_VALUE, 36));
        form.add(genderRow);
        form.add(Box.createVerticalStrut(6));

        form.add(buildField("Mã giới thiệu", false, txtReferral, lblReferralError, "8 ký tự chữ hoa và số (không bắt buộc)"));
        form.add(Box.createVerticalStrut(12));

        // Agree row
        JPanel agreeRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        agreeRow.setBackground(BG_COLOR);
        agreeRow.add(chkAgree);
        agreeRow.add(btnViewTerms);
        agreeRow.setAlignmentX(Component.LEFT_ALIGNMENT);
        agreeRow.setMaximumSize(new Dimension(Integer.MAX_VALUE, 36));
        form.add(agreeRow);
        form.add(lblAgreeError);
        form.add(Box.createVerticalStrut(16));

        // Button row
        JPanel btnRow = new JPanel(new FlowLayout(FlowLayout.CENTER, 16, 0));
        btnRow.setBackground(BG_COLOR);
        btnRow.add(btnRegister);
        btnRow.add(btnLogin);
        btnRow.setAlignmentX(Component.LEFT_ALIGNMENT);
        btnRow.setMaximumSize(new Dimension(Integer.MAX_VALUE, 50));
        form.add(btnRow);

        JScrollPane scroll = new JScrollPane(form);
        scroll.setBorder(null);
        scroll.getVerticalScrollBar().setUnitIncrement(16);
        add(scroll, BorderLayout.CENTER);
    }

    // ──────────────────────────────────────────────────────────────────────────
    // Builders & Helpers
    // ──────────────────────────────────────────────────────────────────────────
    private JPanel buildField(String labelText, boolean required,
                              JComponent input, JLabel errorLabel, String hint) {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBackground(BG_COLOR);
        panel.setAlignmentX(Component.LEFT_ALIGNMENT);

        JPanel row = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        row.setBackground(BG_COLOR);

        JLabel lbl = new JLabel(labelText + (required ? " *" : ""));
        lbl.setFont(new Font("Segoe UI", Font.BOLD, 13));
        lbl.setForeground(required ? LABEL_FG : new Color(0x607D8B));
        lbl.setPreferredSize(new Dimension(165, 28));
        row.add(lbl);

        input.setPreferredSize(new Dimension(340, 32));
        input.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        row.add(input);

        panel.add(row);

        JLabel hintLbl = new JLabel("  ℹ " + hint);
        hintLbl.setFont(new Font("Segoe UI", Font.ITALIC, 11));
        hintLbl.setForeground(new Color(0x90A4AE));
        hintLbl.setAlignmentX(Component.LEFT_ALIGNMENT);
        panel.add(hintLbl);
        panel.add(errorLabel);

        panel.setMaximumSize(new Dimension(Integer.MAX_VALUE, 85));
        return panel;
    }

    private JTextField createTextField(int maxLen) {
        JTextField tf = new JTextField();
        tf.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER_C, 1, true),
                new EmptyBorder(4, 8, 4, 8)));
        return tf;
    }

    private JPasswordField createPasswordField() {
        JPasswordField pf = new JPasswordField();
        pf.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER_C, 1, true),
                new EmptyBorder(4, 8, 4, 8)));
        return pf;
    }

    private JLabel createErrorLabel() {
        JLabel lbl = new JLabel(" ");
        lbl.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        lbl.setForeground(DANGER);
        lbl.setAlignmentX(Component.LEFT_ALIGNMENT);
        lbl.setBorder(new EmptyBorder(0, 168, 0, 0));
        return lbl;
    }

    private void styleRadio(JRadioButton rb) {
        rb.setBackground(BG_COLOR);
        rb.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        rb.setForeground(LABEL_FG);
    }

    // ──────────────────────────────────────────────────────────────────────────
    // Listeners
    // ──────────────────────────────────────────────────────────────────────────
    private void addListeners() {
        // Placeholder ngày sinh
        txtBirthday.addFocusListener(new FocusAdapter() {
            public void focusGained(FocusEvent e) {
                if (txtBirthday.getText().equals("dd/mm/yyyy")) {
                    txtBirthday.setText("");
                    txtBirthday.setForeground(Color.BLACK);
                }
            }
            public void focusLost(FocusEvent e) {
                if (txtBirthday.getText().isEmpty()) {
                    txtBirthday.setText("dd/mm/yyyy");
                    txtBirthday.setForeground(Color.GRAY);
                }
                validateBirthday();
                updateRegisterButton();
            }
        });

        // Real-time validate từng trường
        addDocumentListener(txtFullName,   () -> { validateFullName();   updateRegisterButton(); });
        addDocumentListener(txtUsername,   () -> { validateUsername();   updateRegisterButton(); });
        addDocumentListener(txtEmail,      () -> { validateEmail();      updateRegisterButton(); });
        addDocumentListener(txtPhone,      () -> { validatePhone();      updateRegisterButton(); });
        addDocumentListener(txtPassword,   () -> { validatePassword();   updateRegisterButton(); });
        addDocumentListener(txtConfirmPassword, () -> { validateConfirm(); updateRegisterButton(); });
        addDocumentListener(txtReferral,   () -> { validateReferral();   updateRegisterButton(); });

        chkAgree.addActionListener(e -> { validateAgree(); updateRegisterButton(); });

        // Nút Đăng ký
        btnRegister.addActionListener(e -> handleRegister());

        // Nút Đăng nhập
        btnLogin.addActionListener(e ->
            JOptionPane.showMessageDialog(this, "Chuyển sang trang Đăng Nhập...",
                    "Đăng Nhập", JOptionPane.INFORMATION_MESSAGE));
    }

    private void addDocumentListener(JTextField tf, Runnable action) {
        tf.getDocument().addDocumentListener(new javax.swing.event.DocumentListener() {
            public void insertUpdate(javax.swing.event.DocumentEvent e)  { action.run(); }
            public void removeUpdate(javax.swing.event.DocumentEvent e)  { action.run(); }
            public void changedUpdate(javax.swing.event.DocumentEvent e) { action.run(); }
        });
    }

    private void addDocumentListener(JPasswordField pf, Runnable action) {
        pf.getDocument().addDocumentListener(new javax.swing.event.DocumentListener() {
            public void insertUpdate(javax.swing.event.DocumentEvent e)  { action.run(); }
            public void removeUpdate(javax.swing.event.DocumentEvent e)  { action.run(); }
            public void changedUpdate(javax.swing.event.DocumentEvent e) { action.run(); }
        });
    }

    // ──────────────────────────────────────────────────────────────────────────
    // Validation methods
    // ──────────────────────────────────────────────────────────────────────────
    private boolean validateFullName() {
        String v = txtFullName.getText().trim();
        if (v.isEmpty()) {
            setError(txtFullName, lblFullNameError, "Họ và tên không được để trống.");
            return false;
        }
        if (!FULLNAME_PATTERN.matcher(v).matches()) {
            setError(txtFullName, lblFullNameError, "Chỉ gồm chữ cái (có dấu) và dấu cách, 2–50 ký tự.");
            return false;
        }
        clearError(txtFullName, lblFullNameError);
        return true;
    }

    private boolean validateUsername() {
        String v = txtUsername.getText().trim();
        if (v.isEmpty()) {
            setError(txtUsername, lblUsernameError, "Tên đăng nhập không được để trống.");
            return false;
        }
        if (!USERNAME_PATTERN.matcher(v).matches()) {
            setError(txtUsername, lblUsernameError, "5–20 ký tự, chữ thường/số/gạch dưới, bắt đầu bằng chữ cái.");
            return false;
        }
        if (EXISTING_USERNAMES.contains(v)) {
            setError(txtUsername, lblUsernameError, "Tên đăng nhập đã tồn tại trong hệ thống.");
            return false;
        }
        clearError(txtUsername, lblUsernameError);
        return true;
    }

    private boolean validateEmail() {
        String v = txtEmail.getText().trim();
        if (v.isEmpty()) {
            setError(txtEmail, lblEmailError, "Email không được để trống.");
            return false;
        }
        if (!EMAIL_PATTERN.matcher(v).matches()) {
            setError(txtEmail, lblEmailError, "Email không đúng định dạng RFC 5322.");
            return false;
        }
        if (EXISTING_EMAILS.contains(v.toLowerCase())) {
            setError(txtEmail, lblEmailError, "Email đã được đăng ký trong hệ thống.");
            return false;
        }
        clearError(txtEmail, lblEmailError);
        return true;
    }

    private boolean validatePhone() {
        String v = txtPhone.getText().trim();
        if (v.isEmpty()) {
            setError(txtPhone, lblPhoneError, "Số điện thoại không được để trống.");
            return false;
        }
        if (!PHONE_PATTERN.matcher(v).matches()) {
            setError(txtPhone, lblPhoneError, "Số VN hợp lệ: bắt đầu bằng 0, gồm 10 chữ số.");
            return false;
        }
        clearError(txtPhone, lblPhoneError);
        return true;
    }

    private boolean validatePassword() {
        String v = new String(txtPassword.getPassword());
        if (v.isEmpty()) {
            setError(txtPassword, lblPasswordError, "Mật khẩu không được để trống.");
            return false;
        }
        if (!PASSWORD_PATTERN.matcher(v).matches()) {
            setError(txtPassword, lblPasswordError,
                    "8–32 ký tự, cần ít nhất 1 hoa, 1 thường, 1 số, 1 ký tự đặc biệt (!@#$%).");
            return false;
        }
        clearError(txtPassword, lblPasswordError);
        return true;
    }

    private boolean validateConfirm() {
        String p = new String(txtPassword.getPassword());
        String c = new String(txtConfirmPassword.getPassword());
        if (c.isEmpty()) {
            setError(txtConfirmPassword, lblConfirmError, "Xác nhận mật khẩu không được để trống.");
            return false;
        }
        if (!p.equals(c)) {
            setError(txtConfirmPassword, lblConfirmError, "Xác nhận mật khẩu không khớp.");
            return false;
        }
        clearError(txtConfirmPassword, lblConfirmError);
        return true;
    }

    private boolean validateBirthday() {
        String v = txtBirthday.getText().trim();
        if (v.isEmpty() || v.equals("dd/mm/yyyy")) {
            clearError(txtBirthday, lblBirthdayError);
            return true; // optional
        }
        try {
            LocalDate dob = LocalDate.parse(v, DATE_FORMATTER);
            LocalDate today = LocalDate.now();
            int age = today.getYear() - dob.getYear();
            if (dob.plusYears(age).isAfter(today)) age--;
            if (age < 16) {
                setError(txtBirthday, lblBirthdayError, "Phải đủ 16 tuổi trở lên.");
                return false;
            }
            if (age >= 100) {
                setError(txtBirthday, lblBirthdayError, "Tuổi phải dưới 100.");
                return false;
            }
            clearError(txtBirthday, lblBirthdayError);
            return true;
        } catch (DateTimeParseException ex) {
            setError(txtBirthday, lblBirthdayError, "Định dạng ngày không hợp lệ. Dùng dd/mm/yyyy.");
            return false;
        }
    }

    private boolean validateReferral() {
        String v = txtReferral.getText().trim();
        if (v.isEmpty()) {
            clearError(txtReferral, lblReferralError);
            return true; // optional
        }
        if (!REFERRAL_PATTERN.matcher(v).matches()) {
            setError(txtReferral, lblReferralError, "Mã gồm đúng 8 ký tự chữ hoa và số.");
            return false;
        }
        // Server-side check (giả lập)
        if (!VALID_REFERRAL_CODES.contains(v)) {
            setError(txtReferral, lblReferralError, "Mã giới thiệu không tồn tại trong CSDL.");
            return false;
        }
        clearError(txtReferral, lblReferralError);
        return true;
    }

    private boolean validateAgree() {
        if (!chkAgree.isSelected()) {
            lblAgreeError.setText("  Bạn phải đồng ý với Điều khoản dịch vụ.");
            return false;
        }
        lblAgreeError.setText(" ");
        return true;
    }

    // ──────────────────────────────────────────────────────────────────────────
    // Cập nhật trạng thái nút Đăng Ký
    // ──────────────────────────────────────────────────────────────────────────
    private void updateRegisterButton() {
        boolean allRequired =
                !txtFullName.getText().trim().isEmpty() &&
                !txtUsername.getText().trim().isEmpty() &&
                !txtEmail.getText().trim().isEmpty() &&
                !txtPhone.getText().trim().isEmpty() &&
                txtPassword.getPassword().length > 0 &&
                txtConfirmPassword.getPassword().length > 0 &&
                chkAgree.isSelected();
        btnRegister.setEnabled(allRequired);
    }

    // ──────────────────────────────────────────────────────────────────────────
    // Xử lý submit
    // ──────────────────────────────────────────────────────────────────────────
    private void handleRegister() {
        boolean ok = validateFullName()
                   & validateUsername()
                   & validateEmail()
                   & validatePhone()
                   & validatePassword()
                   & validateConfirm()
                   & validateBirthday()
                   & validateReferral()
                   & validateAgree();

        if (ok) {
            // Giả lập gửi CSDL thành công
            EXISTING_USERNAMES.add(txtUsername.getText().trim());
            EXISTING_EMAILS.add(txtEmail.getText().trim().toLowerCase());

            JOptionPane.showMessageDialog(this,
                    "🎉 Đăng ký tài khoản thành công!\n" +
                    "Chào mừng " + txtFullName.getText().trim() + " đến với ShopVN.vn!",
                    "Thành Công", JOptionPane.INFORMATION_MESSAGE);
            dispose();
        }
    }

    // ──────────────────────────────────────────────────────────────────────────
    // Popup Xem Điều Khoản
    // ──────────────────────────────────────────────────────────────────────────
    private void showTermsPopup() {
        JDialog dialog = new JDialog(this, "Điều Khoản Dịch Vụ – ShopVN.vn", true);
        dialog.setSize(520, 400);
        dialog.setLocationRelativeTo(this);

        JTextArea ta = new JTextArea();
        ta.setEditable(false);
        ta.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        ta.setLineWrap(true);
        ta.setWrapStyleWord(true);
        ta.setBorder(new EmptyBorder(16, 16, 16, 16));
        ta.setText(
            "ĐIỀU KHOẢN DỊCH VỤ – SHOPVN.VN\n\n" +
            "1. Người dùng phải từ 16 tuổi trở lên.\n\n" +
            "2. Thông tin cá nhân được bảo mật theo chính sách GDPR.\n\n" +
            "3. Tài khoản chỉ được sử dụng cho mục đích hợp pháp.\n\n" +
            "4. ShopVN.vn có quyền khóa tài khoản vi phạm điều khoản.\n\n" +
            "5. Người dùng chịu trách nhiệm về mật khẩu và bảo mật tài khoản.\n\n" +
            "6. Mọi tranh chấp được giải quyết theo pháp luật Việt Nam.\n\n" +
            "Bằng cách nhấn 'Đăng Ký', bạn xác nhận đã đọc và đồng ý\n" +
            "với toàn bộ Điều Khoản Dịch Vụ trên."
        );

        JButton btnClose = new JButton("Đóng");
        btnClose.addActionListener(e -> dialog.dispose());
        btnClose.setFont(new Font("Segoe UI", Font.BOLD, 13));

        dialog.setLayout(new BorderLayout());
        dialog.add(new JScrollPane(ta), BorderLayout.CENTER);
        JPanel btnPanel = new JPanel();
        btnPanel.add(btnClose);
        dialog.add(btnPanel, BorderLayout.SOUTH);
        dialog.setVisible(true);
    }

    // ──────────────────────────────────────────────────────────────────────────
    // Helpers UI
    // ──────────────────────────────────────────────────────────────────────────
    private void setError(JComponent comp, JLabel errorLabel, String msg) {
        comp.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(DANGER, 1, true),
                new EmptyBorder(4, 8, 4, 8)));
        errorLabel.setText("  ✗ " + msg);
    }

    private void clearError(JComponent comp, JLabel errorLabel) {
        comp.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(0x4CAF50), 1, true),
                new EmptyBorder(4, 8, 4, 8)));
        errorLabel.setText("  ✓");
        errorLabel.setForeground(SUCCESS);
    }

    // ──────────────────────────────────────────────────────────────────────────
    // Main
    // ──────────────────────────────────────────────────────────────────────────
    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception ignored) {}
        SwingUtilities.invokeLater(() -> new RegisterForm().setVisible(true));
    }
}
