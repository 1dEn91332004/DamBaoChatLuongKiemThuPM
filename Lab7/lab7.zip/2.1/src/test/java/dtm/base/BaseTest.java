package dtm.base;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

import java.io.File;
import java.lang.reflect.Method;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * BaseTest – Lớp nền cho tất cả test classes.
 *
 * Chức năng:
 * - Khởi tạo ChromeDriver an toàn cho đa luồng via ThreadLocal
 * - @BeforeMethod: setup driver, maximize, implicitWait
 * - @AfterMethod: chụp screenshot khi FAILURE, đóng driver
 * - getDriver(): trả về driver của thread hiện tại
 */
public abstract class BaseTest {

    // ── ThreadLocal giữ driver riêng biệt cho mỗi thread (parallel safe) ──
    private static final ThreadLocal<WebDriver> driverThreadLocal = new ThreadLocal<>();

    // ── URL ứng dụng (có thể override trong subclass) ──
    protected static final String BASE_URL = "https://www.saucedemo.com";

    // ── Thư mục lưu screenshot ──
    private static final String SCREENSHOT_DIR = "screenshots";

    // ──────────────────────────────────────────────────────────────────────────
    // @BeforeMethod – Chạy trước mỗi test method
    // ──────────────────────────────────────────────────────────────────────────
    @BeforeMethod(alwaysRun = true)
    public void setUp(Method method) {
        // 1. Log tên test đang chạy
        System.out.println("\n========================================");
        System.out.println("[SETUP] Đang chạy test: " + method.getName());
        System.out.println("[SETUP] Thread: " + Thread.currentThread().getId());
        System.out.println("========================================");

        // 2. Khởi tạo ChromeDriver qua WebDriverManager
        WebDriverManager.chromedriver().setup();

        ChromeOptions options = new ChromeOptions();
        // options.addArguments("--headless"); // Bỏ comment nếu chạy headless
        options.addArguments("--no-sandbox");
        options.addArguments("--disable-dev-shm-usage");
        options.addArguments("--disable-gpu");
        options.addArguments("--remote-allow-origins=*");

        WebDriver driver = new ChromeDriver(options);

        // 3. Maximize window
        driver.manage().window().maximize();

        // 4. Set implicit wait 10 giây
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));

        // 5. Lưu driver vào ThreadLocal
        driverThreadLocal.set(driver);

        System.out.println("[SETUP] ChromeDriver khởi tạo thành công.");
    }

    // ──────────────────────────────────────────────────────────────────────────
    // @AfterMethod – Chạy sau mỗi test method
    // ──────────────────────────────────────────────────────────────────────────
    @AfterMethod(alwaysRun = true)
    public void tearDown(ITestResult result) {
        WebDriver driver = getDriver();

        try {
            // Nếu test FAIL → chụp screenshot
            if (result.getStatus() == ITestResult.FAILURE) {
                takeScreenshot(result.getName());
                System.out.println("[TEARDOWN] Test FAILED – Screenshot đã lưu.");
            } else if (result.getStatus() == ITestResult.SUCCESS) {
                System.out.println("[TEARDOWN] Test PASSED: " + result.getName());
            } else {
                System.out.println("[TEARDOWN] Test SKIPPED: " + result.getName());
            }
        } finally {
            // Đóng driver và xóa khỏi ThreadLocal
            if (driver != null) {
                driver.quit();
                System.out.println("[TEARDOWN] Driver đã đóng.");
            }
            driverThreadLocal.remove();
        }
    }

    // ──────────────────────────────────────────────────────────────────────────
    // getDriver() – Trả về WebDriver của thread hiện tại
    // ──────────────────────────────────────────────────────────────────────────
    public WebDriver getDriver() {
        return driverThreadLocal.get();
    }

    // ──────────────────────────────────────────────────────────────────────────
    // Chụp Screenshot khi FAIL
    // ──────────────────────────────────────────────────────────────────────────
    private void takeScreenshot(String testName) {
        try {
            WebDriver driver = getDriver();
            if (!(driver instanceof TakesScreenshot))
                return;

            // Tạo thư mục screenshots nếu chưa có
            Path screenshotDir = Paths.get(SCREENSHOT_DIR);
            if (!Files.exists(screenshotDir)) {
                Files.createDirectories(screenshotDir);
            }

            // Tên file: testName_yyyy-MM-dd_HH-mm-ss.png
            String timestamp = LocalDateTime.now()
                    .format(DateTimeFormatter.ofPattern("yyyy-MM-dd_HH-mm-ss"));
            String fileName = testName + "_" + timestamp + ".png";
            Path destination = screenshotDir.resolve(fileName);

            // Chụp và lưu
            File screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
            Files.copy(screenshot.toPath(), destination, StandardCopyOption.REPLACE_EXISTING);

            System.out.println("[SCREENSHOT] Đã lưu: " + destination.toAbsolutePath());
        } catch (Exception e) {
            System.err.println("[SCREENSHOT] Lỗi khi chụp screenshot: " + e.getMessage());
        }
    }
}
