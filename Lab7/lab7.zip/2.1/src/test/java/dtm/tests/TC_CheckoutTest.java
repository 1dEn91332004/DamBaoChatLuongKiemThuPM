package dtm.tests;

import dtm.base.BaseTest;
import dtm.data.GioHangData;
import dtm.pages.CartPage;
import dtm.pages.CheckoutPage;
import dtm.pages.InventoryPage;
import dtm.pages.LoginPage;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.lang.reflect.Method;

/**
 * TC_CheckoutTest – Kiểm thử chức năng Thanh Toán (Checkout)
 */
public class TC_CheckoutTest extends BaseTest {

    private static final String BASE_URL = "https://www.saucedemo.com";
    private CartPage cartPage;

    /** Đăng nhập + thêm sản phẩm + vào giỏ trước mỗi test */
    @BeforeMethod(alwaysRun = true)
    public void setupWithProduct(Method method) {
        super.setUp(method);

        InventoryPage inventoryPage = new LoginPage(getDriver())
                .open(BASE_URL)
                .loginAs("standard_user", "secret_sauce");

        Assert.assertTrue(inventoryPage.isOnInventoryPage());
        inventoryPage.addToCartByName("Sauce Labs Backpack");
        cartPage = inventoryPage.goToCart();
        Assert.assertTrue(cartPage.isOnCartPage());
    }

    /**
     * TC_CART_006 → TC_CART_009: Checkout với các tập dữ liệu EP
     * - Hợp lệ: hoàn thành đơn hàng
     * - Không hợp lệ: hiển thị lỗi thiếu thông tin
     */
    @Test(dataProvider = "cartCheckoutData", dataProviderClass = GioHangData.class, groups = {
            "regression" }, description = "Kiểm tra thanh toán với dữ liệu EP (hợp lệ + không hợp lệ)")
    public void testCheckout(String tcId, String firstName, String lastName,
            String zip, boolean isValid) {

        System.out.println("[TEST] " + tcId
                + " | firstName=" + firstName
                + " | lastName=" + lastName
                + " | zip=" + zip);

        CheckoutPage checkout = cartPage.proceedToCheckout();

        if (isValid) {
            // ── Hợp lệ: hoàn thành đơn hàng ──
            checkout.fillInfo(firstName, lastName, zip)
                    .clickFinish();
            Assert.assertTrue(checkout.isOrderComplete(),
                    "[" + tcId + "] Đặt hàng thành công nhưng KHÔNG hiện màn hình hoàn thành!");
            System.out.println("[PASS] " + tcId + " – Đặt hàng thành công!");
        } else {
            // ── Không hợp lệ: phải báo lỗi ──
            checkout.enterFirstName(firstName)
                    .enterLastName(lastName)
                    .enterZipCode(zip)
                    .clickContinue();
            Assert.assertTrue(checkout.isErrorDisplayed(),
                    "[" + tcId + "] Thiếu thông tin nhưng KHÔNG hiện thông báo lỗi!");
            System.out.println("[PASS] " + tcId + " – Lỗi: " + checkout.getErrorMessage());
        }
    }

    /** Smoke: Happy path checkout hoàn chỉnh */
    @Test(groups = { "smoke" }, description = "Smoke – Thanh toán thành công từ đầu đến cuối")
    public void testCheckoutHappyPath() {
        CheckoutPage checkout = cartPage.proceedToCheckout();
        checkout.fillInfo("Nguyen", "Van A", "70000")
                .clickFinish();
        Assert.assertTrue(checkout.isOrderComplete(),
                "Happy path checkout FAILED!");
        System.out.println("[PASS] Smoke checkout hoàn thành thành công.");
    }
}
