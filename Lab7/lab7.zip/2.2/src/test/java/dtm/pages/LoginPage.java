package dtm.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

/**
 * LoginPage – Page Object cho trang đăng nhập saucedemo.com
 *
 * Yêu cầu 2.2: Sử dụng @FindBy + PageFactory.initElements
 * URL: https://www.saucedemo.com
 */
public class LoginPage {

    private WebDriver driver;
    private WebDriverWait wait;

    // ── Khai báo WebElement bằng @FindBy ──
    @FindBy(id = "user-name")
    private WebElement userNameField;

    @FindBy(id = "password")
    private WebElement passwordField;

    @FindBy(id = "login-button")
    private WebElement loginButton;

    @FindBy(css = "[data-test='error']")
    private WebElement errorMessage;

    @FindBy(className = "login_logo")
    private WebElement loginLogo;

    // ── Constructor: khởi tạo PageFactory ──
    public LoginPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(20));
        PageFactory.initElements(driver, this);
    }

    // ────────────────────────────────────────────────────────────────────────
    // Actions
    // ────────────────────────────────────────────────────────────────────────

    /** Mở trang đăng nhập */
    public LoginPage moTrang(String url) {
        driver.get(url);
        wait.until(ExpectedConditions.visibilityOf(loginLogo));
        return this;
    }

    /** Nhập username (xử lý null) */
    public void nhapUsername(String username) {
        wait.until(ExpectedConditions.visibilityOf(userNameField));
        userNameField.clear();
        if (username != null) {
            userNameField.sendKeys(username);
        }
        // null → không nhập gì (giả lập trường trống)
    }

    /** Nhập password (xử lý null) */
    public void nhapPassword(String password) {
        passwordField.clear();
        if (password != null) {
            passwordField.sendKeys(password);
        }
    }

    /** Nhấn nút Đăng Nhập */
    public void clickDangNhap() {
        wait.until(ExpectedConditions.elementToBeClickable(loginButton)).click();
    }

    /** Thực hiện đăng nhập đầy đủ (username, password, click) */
    public void dangNhap(String username, String password) {
        nhapUsername(username);
        nhapPassword(password);
        clickDangNhap();
    }

    // ────────────────────────────────────────────────────────────────────────
    // Verifications
    // ────────────────────────────────────────────────────────────────────────

    /**
     * Trả về nội dung thông báo lỗi, null nếu không có lỗi
     */
    public String layThongBaoLoi() {
        try {
            wait.until(ExpectedConditions.visibilityOf(errorMessage));
            return errorMessage.getText();
        } catch (Exception e) {
            return null;
        }
    }

    /**
     * Kiểm tra đã chuyển sang trang inventory chưa
     * URL phải chứa "/inventory.html"
     */
    public boolean isDangOTrangSanPham() {
        try {
            wait.until(ExpectedConditions.urlContains("/inventory.html"));
            return driver.getCurrentUrl().contains("/inventory.html");
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * Kiểm tra vẫn đang ở trang login (đăng nhập thất bại)
     */
    public boolean isDangOTrangDangNhap() {
        return driver.getCurrentUrl().equals("https://www.saucedemo.com/")
                || driver.getCurrentUrl().equals("https://www.saucedemo.com");
    }
}
