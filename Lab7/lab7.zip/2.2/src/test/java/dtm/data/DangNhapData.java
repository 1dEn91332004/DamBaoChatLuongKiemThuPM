package dtm.data;

import org.testng.annotations.DataProvider;

/**
 * DangNhapData – @DataProvider cho TC_DangNhapTest
 *
 * Yêu cầu 2.1 – Sinh viên tự thiết kế dữ liệu bao gồm:
 * 1. Tất cả tài khoản hợp lệ từ saucedemo.com
 * 2. Tài khoản không tồn tại
 * 3. Để trống username / password / cả hai
 * 4. Username có ký tự đặc biệt, khoảng trắng đầu/cuối
 * 5. Giá trị null
 *
 * Cột: username | password | ketQuaMongDoi | moTa
 * ketQuaMongDoi: THANH_CONG | SAI_THONG_TIN | BI_KHOA | TRUONG_TRONG
 */
public class DangNhapData {

    @DataProvider(name = "du_lieu_dang_nhap")
    public Object[][] getData() {
        return new Object[][] {

                // ─────────────────────────────────────────────────
                // NHÓM 1: Tài khoản HỢP LỆ từ saucedemo.com
                // ─────────────────────────────────────────────────
                {
                        "standard_user",
                        "secret_sauce",
                        "THANH_CONG",
                        "TC01 – Tài khoản chuẩn, đăng nhập thành công"
                },
                {
                        "problem_user",
                        "secret_sauce",
                        "THANH_CONG",
                        "TC02 – problem_user đăng nhập được nhưng UI sản phẩm lỗi"
                },
                {
                        "performance_glitch_user",
                        "secret_sauce",
                        "THANH_CONG",
                        "TC03 – performance_glitch_user đăng nhập chậm nhưng thành công"
                },
                {
                        "error_user",
                        "secret_sauce",
                        "THANH_CONG",
                        "TC04 – error_user đăng nhập được nhưng một số action lỗi"
                },

                // ─────────────────────────────────────────────────
                // NHÓM 2: Tài khoản BỊ KHOÁ
                // ─────────────────────────────────────────────────
                {
                        "locked_out_user",
                        "secret_sauce",
                        "BI_KHOA",
                        "TC05 – Tài khoản bị khoá, thông báo 'user has been locked out'"
                },

                // ─────────────────────────────────────────────────
                // NHÓM 3: Tài khoản KHÔNG TỒN TẠI
                // ─────────────────────────────────────────────────
                {
                        "nguyen_van_a",
                        "password123",
                        "SAI_THONG_TIN",
                        "TC06 – Username không tồn tại trong hệ thống"
                },
                {
                        "standard_user",
                        "wrong_password",
                        "SAI_THONG_TIN",
                        "TC07 – Username đúng nhưng password sai"
                },
                {
                        "khong_ton_tai",
                        "khong_ton_tai",
                        "SAI_THONG_TIN",
                        "TC08 – Cả username lẫn password đều sai"
                },

                // ─────────────────────────────────────────────────
                // NHÓM 4: Để TRỐNG username / password / cả hai
                // ─────────────────────────────────────────────────
                {
                        "",
                        "secret_sauce",
                        "TRUONG_TRONG",
                        "TC09 – Username để trống, password hợp lệ"
                },
                {
                        "standard_user",
                        "",
                        "TRUONG_TRONG",
                        "TC10 – Username hợp lệ, password để trống"
                },
                {
                        "",
                        "",
                        "TRUONG_TRONG",
                        "TC11 – Cả hai trường đều để trống"
                },

                // ─────────────────────────────────────────────────
                // NHÓM 5: Username có KÝ TỰ ĐẶC BIỆT / khoảng trắng
                // ─────────────────────────────────────────────────
                {
                        " standard_user",
                        "secret_sauce",
                        "SAI_THONG_TIN",
                        "TC12 – Username có khoảng trắng ĐẦU (leading space)"
                },
                {
                        "standard_user ",
                        "secret_sauce",
                        "SAI_THONG_TIN",
                        "TC13 – Username có khoảng trắng CUỐI (trailing space)"
                },
                {
                        "standard user",
                        "secret_sauce",
                        "SAI_THONG_TIN",
                        "TC14 – Username có khoảng trắng GIỮA"
                },
                {
                        "standard_user!@#",
                        "secret_sauce",
                        "SAI_THONG_TIN",
                        "TC15 – Username có ký tự đặc biệt !@#"
                },
                {
                        "<script>alert(1)</script>",
                        "secret_sauce",
                        "SAI_THONG_TIN",
                        "TC16 – Username chứa XSS payload"
                },

                // ─────────────────────────────────────────────────
                // NHÓM 6: Giá trị NULL
                // ─────────────────────────────────────────────────
                {
                        null,
                        "secret_sauce",
                        "TRUONG_TRONG",
                        "TC17 – Username là null (xử lý NullPointerException)"
                },
                {
                        "standard_user",
                        null,
                        "TRUONG_TRONG",
                        "TC18 – Password là null (xử lý NullPointerException)"
                },
        };
    }
}
