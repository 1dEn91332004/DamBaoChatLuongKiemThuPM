package dtm.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

/** CheckoutPage – Page Object cho /checkout-step-one, step-two, complete */
public class CheckoutPage {

    private final WebDriver driver;
    private final WebDriverWait wait;

    // ── Step 1 ──
    @FindBy(id = "first-name")
    private WebElement firstNameField;
    @FindBy(id = "last-name")
    private WebElement lastNameField;
    @FindBy(id = "postal-code")
    private WebElement zipField;
    @FindBy(id = "continue")
    private WebElement continueBtn;
    @FindBy(id = "cancel")
    private WebElement cancelBtn;
    @FindBy(css = "[data-test='error']")
    private WebElement errorMsg;

    // ── Step 2 ──
    @FindBy(css = ".summary_subtotal_label")
    private WebElement itemTotalEl;
    @FindBy(css = ".summary_tax_label")
    private WebElement taxEl;
    @FindBy(css = ".summary_total_label")
    private WebElement totalEl;
    @FindBy(id = "finish")
    private WebElement finishBtn;

    // ── Complete ──
    @FindBy(className = "complete-header")
    private WebElement completeHeader;
    @FindBy(id = "back-to-products")
    private WebElement backHomeBtn;

    public CheckoutPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        PageFactory.initElements(driver, this);
    }

    // ── Step 1 actions ──
    public CheckoutPage nhapThongTin(String fn, String ln, String zip) {
        wait.until(ExpectedConditions.visibilityOf(firstNameField));
        firstNameField.clear();
        firstNameField.sendKeys(fn != null ? fn : "");
        lastNameField.clear();
        lastNameField.sendKeys(ln != null ? ln : "");
        zipField.clear();
        zipField.sendKeys(zip != null ? zip : "");
        return this;
    }

    public CheckoutPage nhanContinue() {
        continueBtn.click();
        return this;
    }

    public CartPage nhanCancelStep1() {
        cancelBtn.click();
        return new CartPage(driver);
    }

    public String layThongBaoLoi() {
        try {
            return wait.until(ExpectedConditions.visibilityOf(errorMsg)).getText();
        } catch (Exception e) {
            return null;
        }
    }

    public boolean isLoi() {
        return layThongBaoLoi() != null;
    }

    // ── Step 2 verifications ──
    public boolean isDangOStep2() {
        try {
            wait.until(ExpectedConditions.urlContains("step-two"));
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    /** Lay gia tri Item total (truoc thue) – vi du: "$21.98" -> 21.98 */
    public double layItemTotal() {
        wait.until(ExpectedConditions.visibilityOf(itemTotalEl));
        String text = itemTotalEl.getText(); // "Item total: $21.98"
        return Double.parseDouble(text.replaceAll("[^0-9.]", ""));
    }

    /** Lay gia tri Tax */
    public double layTax() {
        String text = taxEl.getText(); // "Tax: $1.76"
        return Double.parseDouble(text.replaceAll("[^0-9.]", ""));
    }

    /** Lay gia tri Total */
    public double layTotal() {
        String text = totalEl.getText(); // "Total: $23.74"
        return Double.parseDouble(text.replaceAll("[^0-9.]", ""));
    }

    public InventoryPage nhanCancelStep2() {
        driver.findElement(By.id("cancel")).click();
        return new InventoryPage(driver);
    }

    public CheckoutPage nhanFinish() {
        wait.until(ExpectedConditions.elementToBeClickable(finishBtn)).click();
        return this;
    }

    // ── Complete ──
    public boolean isDonHangHoanThanh() {
        try {
            return wait.until(ExpectedConditions.visibilityOf(completeHeader))
                    .getText().toLowerCase().contains("thank you");
        } catch (Exception e) {
            return false;
        }
    }

    public InventoryPage nhanBackHome() {
        wait.until(ExpectedConditions.elementToBeClickable(backHomeBtn)).click();
        return new InventoryPage(driver);
    }
}
