package dtm.tests;

import dtm.base.BaseTest;
import dtm.pages.CartPage;
import dtm.pages.CheckoutPage;
import dtm.pages.InventoryPage;
import dtm.pages.LoginPage;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.lang.reflect.Method;
import java.util.List;

/**
 * TC_GioHangTest – Kiem thu Gio Hang va Checkout End-to-End
 * Yeu cau 2.3.B + 2.3.C
 *
 * Co it nhat 10 test method tuong ung voi danh sach TC da thiet ke o YC 2.3.A
 */
public class TC_GioHangTest extends BaseTest {

    private static final String URL = "https://www.saucedemo.com";
    private static final String USER = "standard_user";
    private static final String PASS = "secret_sauce";

    InventoryPage inventoryPage;
    CartPage cartPage;

    // ── Dang nhap truoc moi test ──
    @BeforeMethod(alwaysRun = true)
    public void chuanBi(Method method) {
        super.setUp(method);
        LoginPage lp = new LoginPage(getDriver());
        lp.moTrang(URL);
        lp.dangNhap(USER, PASS);
        inventoryPage = new InventoryPage(getDriver());
        Assert.assertTrue(inventoryPage.isDangOTrangInventory(),
                "Khong vao duoc trang san pham");
    }

    // ──────────────────────────────────────────────────────────────────────────
    // NHOM 1: Them san pham
    // ──────────────────────────────────────────────────────────────────────────

    @Test(groups = "smoke", description = "TC_CART_001: Them 1 san pham – badge = 1")
    public void themMotSanPham() {
        inventoryPage.themSanPhamTheoTen("Sauce Labs Backpack");
        Assert.assertEquals(inventoryPage.laySoLuongBadge(), 1,
                "Badge phai = 1 sau khi them 1 san pham");
        System.out.println("[PASS] TC_CART_001 – badge = 1");
    }

    @Test(groups = "smoke", description = "TC_CART_002: Them 3 san pham – badge = 3")
    public void them3SanPham() {
        inventoryPage.themNSanPhamDauTien(3);
        Assert.assertEquals(inventoryPage.laySoLuongBadge(), 3,
                "Badge phai = 3 sau khi them 3 san pham");
        System.out.println("[PASS] TC_CART_002 – badge = 3");
    }

    @Test(groups = "regression", description = "TC_CART_003: Them tat ca 6 san pham – badge = 6")
    public void themTatCaSanPham() {
        inventoryPage.themNSanPhamDauTien(6);
        Assert.assertEquals(inventoryPage.laySoLuongBadge(), 6,
                "Badge phai = 6 sau khi them tat ca san pham");
        System.out.println("[PASS] TC_CART_003 – badge = 6");
    }

    @Test(groups = "regression", description = "TC_CART_004: Gio hang hien thi dung san pham da them")
    public void kiemTraDanhSachGioHang() {
        inventoryPage.themSanPhamTheoTen("Sauce Labs Backpack");
        inventoryPage.themSanPhamTheoTen("Sauce Labs Bike Light");
        cartPage = inventoryPage.diDenGioHang();
        Assert.assertTrue(cartPage.isDangOTrangGioHang());
        List<String> items = cartPage.layDanhSachTenItem();
        Assert.assertTrue(items.contains("Sauce Labs Backpack"),
                "Gio hang phai co Sauce Labs Backpack");
        Assert.assertTrue(items.contains("Sauce Labs Bike Light"),
                "Gio hang phai co Sauce Labs Bike Light");
        System.out.println("[PASS] TC_CART_004 – danh sach khop");
    }

    // ──────────────────────────────────────────────────────────────────────────
    // NHOM 2: Xoa san pham
    // ──────────────────────────────────────────────────────────────────────────

    @Test(groups = "regression", description = "TC_CART_005: Xoa 1 san pham – badge giam 1")
    public void xoaMotSanPham() {
        inventoryPage.themNSanPhamDauTien(2);
        int truoc = inventoryPage.laySoLuongBadge();
        cartPage = inventoryPage.diDenGioHang();
        cartPage.xoaItemTheoTen("sauce-labs-backpack");
        int sau = new InventoryPage(getDriver()).laySoLuongBadge();
        // badge giam 1 hoac bien mat neu con 0
        Assert.assertTrue(sau < truoc,
                "Badge phai giam sau khi xoa san pham");
        System.out.println("[PASS] TC_CART_005 – badge: " + truoc + " -> " + sau);
    }

    @Test(groups = "regression", description = "TC_CART_006: Xoa het – badge bien mat (0)")
    public void xoaHetSanPham() {
        inventoryPage.themNSanPhamDauTien(3);
        cartPage = inventoryPage.diDenGioHang();
        cartPage.xoaTatCaItems();
        Assert.assertEquals(cartPage.laysoLuongItems(), 0,
                "Gio hang phai rong sau khi xoa tat ca");
        Assert.assertEquals(new InventoryPage(getDriver()).laySoLuongBadge(), 0,
                "Badge phai = 0 sau khi xoa het");
        System.out.println("[PASS] TC_CART_006 – gio hang rong, badge = 0");
    }

    @Test(groups = "regression", description = "TC_CART_007: Gio trong – nut Checkout van hien thi")
    public void kiemTraNutCheckoutKhiGioTrong() {
        // Vao gio hang khi chua them gi
        getDriver().get(URL + "/cart.html");
        cartPage = new CartPage(getDriver());
        Assert.assertEquals(cartPage.laysoLuongItems(), 0, "Gio phai trong");
        Assert.assertTrue(cartPage.isCheckoutBtnHienThi(),
                "Nut Checkout van hien thi khi gio trong");
        System.out.println("[PASS] TC_CART_007 – nut Checkout hien thi du gio trong");
    }

    // ──────────────────────────────────────────────────────────────────────────
    // NHOM 3: Sort san pham
    // ──────────────────────────────────────────────────────────────────────────

    @Test(groups = "regression", description = "TC_CART_008: Sort A to Z – Backpack dau tien")
    public void sortAZ() {
        inventoryPage.sortSanPham("az");
        String first = inventoryPage.layDanhSachTenSanPham().get(0);
        Assert.assertEquals(first, "Sauce Labs Backpack",
                "Sort A-Z: san pham dau tien phai la Sauce Labs Backpack");
        System.out.println("[PASS] TC_CART_008 – Sort A-Z: " + first);
    }

    @Test(groups = "regression", description = "TC_CART_009: Sort Z to A – T-Shirt dau tien")
    public void sortZA() {
        inventoryPage.sortSanPham("za");
        String first = inventoryPage.layDanhSachTenSanPham().get(0);
        Assert.assertTrue(first.startsWith("Test.allTheThings"),
                "Sort Z-A: san pham dau tien phai la T-Shirt. Thuc te: " + first);
        System.out.println("[PASS] TC_CART_009 – Sort Z-A: " + first);
    }

    @Test(groups = "regression", description = "TC_CART_010: Sort Price low to high – Onesie dau tien")
    public void sortGiaTangDan() {
        inventoryPage.sortSanPham("lohi");
        List<Double> prices = inventoryPage.layDanhSachGiaSanPham();
        for (int i = 0; i < prices.size() - 1; i++) {
            Assert.assertTrue(prices.get(i) <= prices.get(i + 1),
                    "Sort gia tang dan bi sai tai vi tri " + i
                            + ": " + prices.get(i) + " > " + prices.get(i + 1));
        }
        System.out.println("[PASS] TC_CART_010 – Gia tang dan dung: " + prices);
    }

    @Test(groups = "regression", description = "TC_CART_011: Sort Price high to low – Fleece Jacket dau tien")
    public void sortGiaGiamDan() {
        inventoryPage.sortSanPham("hilo");
        List<Double> prices = inventoryPage.layDanhSachGiaSanPham();
        for (int i = 0; i < prices.size() - 1; i++) {
            Assert.assertTrue(prices.get(i) >= prices.get(i + 1),
                    "Sort gia giam dan bi sai tai vi tri " + i);
        }
        System.out.println("[PASS] TC_CART_011 – Gia giam dan dung: " + prices);
    }

    // ──────────────────────────────────────────────────────────────────────────
    // NHOM 4: Checkout Step 1 – Form validation
    // ──────────────────────────────────────────────────────────────────────────

    @Test(groups = "regression", description = "TC_CART_012: Checkout de trong First Name – loi")
    public void checkoutThieuFirstName() {
        inventoryPage.themNSanPhamDauTien(1);
        cartPage = inventoryPage.diDenGioHang();
        CheckoutPage co = cartPage.nhanCheckout();
        // Nhan Continue truoc, sau do dien -> dam bao truong trong
        co.nhanContinue(); // submit rong
        String loi = co.layThongBaoLoi();
        Assert.assertNotNull(loi, "Phai co thong bao loi khi de trong tat ca");
        Assert.assertTrue(loi.contains("First Name"),
                "Thong bao loi phai noi ve First Name: " + loi);
        System.out.println("[PASS] TC_CART_012 – Loi: " + loi);
    }

    @Test(groups = "regression", description = "TC_CART_013: Checkout de trong Last Name – loi")
    public void checkoutThieuLastName() {
        inventoryPage.themNSanPhamDauTien(1);
        cartPage = inventoryPage.diDenGioHang();
        CheckoutPage co = cartPage.nhanCheckout();
        co.nhapThongTin("Nguyen", "", "70000").nhanContinue();
        String loi = co.layThongBaoLoi();
        Assert.assertTrue(loi != null && loi.contains("Last Name"),
                "Phai co loi 'Last Name is required'");
        System.out.println("[PASS] TC_CART_013 – Loi: " + loi);
    }

    @Test(groups = "regression", description = "TC_CART_014: Checkout de trong Zip Code – loi")
    public void checkoutThieuZipCode() {
        inventoryPage.themNSanPhamDauTien(1);
        cartPage = inventoryPage.diDenGioHang();
        CheckoutPage co = cartPage.nhanCheckout();
        co.nhapThongTin("Nguyen", "Van A", "").nhanContinue();
        String loi = co.layThongBaoLoi();
        Assert.assertTrue(loi != null && loi.contains("Postal Code"),
                "Phai co loi 'Postal Code is required'");
        System.out.println("[PASS] TC_CART_014 – Loi: " + loi);
    }

    @Test(groups = "smoke", description = "TC_CART_015: Checkout dien du – chuyen sang Step 2")
    public void checkoutDienDuThongTin() {
        inventoryPage.themNSanPhamDauTien(1);
        cartPage = inventoryPage.diDenGioHang();
        CheckoutPage co = cartPage.nhanCheckout();
        co.nhapThongTin("Nguyen", "Van A", "70000").nhanContinue();
        Assert.assertTrue(co.isDangOStep2(),
                "Phai chuyen sang Step 2 sau khi dien du thong tin");
        System.out.println("[PASS] TC_CART_015 – Chuyen sang Step 2 thanh cong");
    }

    // ──────────────────────────────────────────────────────────────────────────
    // NHOM 5: Cancel navigation
    // ──────────────────────────────────────────────────────────────────────────

    @Test(groups = "regression", description = "TC_CART_016: Cancel Step 1 – quay lai /cart.html")
    public void cancelStep1QuayLaiGioHang() {
        inventoryPage.themNSanPhamDauTien(1);
        cartPage = inventoryPage.diDenGioHang();
        CheckoutPage co = cartPage.nhanCheckout();
        CartPage quayLai = co.nhanCancelStep1();
        Assert.assertTrue(quayLai.isDangOTrangGioHang(),
                "Cancel Step 1 phai quay ve /cart.html");
        System.out.println("[PASS] TC_CART_016 – Quay lai gio hang OK");
    }

    @Test(groups = "regression", description = "TC_CART_017: Cancel Step 2 – quay lai /inventory.html")
    public void cancelStep2QuayLaiInventory() {
        inventoryPage.themNSanPhamDauTien(1);
        cartPage = inventoryPage.diDenGioHang();
        CheckoutPage co = cartPage.nhanCheckout();
        co.nhapThongTin("Nguyen", "Van A", "70000").nhanContinue();
        Assert.assertTrue(co.isDangOStep2(), "Phai o Step 2 truoc khi cancel");
        InventoryPage back = co.nhanCancelStep2();
        Assert.assertTrue(back.isDangOTrangInventory(),
                "Cancel Step 2 phai quay ve /inventory.html");
        System.out.println("[PASS] TC_CART_017 – Quay lai Inventory OK");
    }

    // ──────────────────────────────────────────────────────────────────────────
    // NHOM 6: Hoan thanh don hang + reset gio
    // ──────────────────────────────────────────────────────────────────────────

    @Test(groups = "smoke", description = "TC_CART_018: Dat hang thanh cong – hien 'Thank you'")
    public void datHangThanhCong() {
        inventoryPage.themNSanPhamDauTien(1);
        cartPage = inventoryPage.diDenGioHang();
        CheckoutPage co = cartPage.nhanCheckout();
        co.nhapThongTin("Nguyen", "Van A", "70000").nhanContinue();
        co.nhanFinish();
        Assert.assertTrue(co.isDonHangHoanThanh(),
                "Phai hien thi 'Thank you for your order!'");
        System.out.println("[PASS] TC_CART_018 – Don hang hoan thanh");
    }

    @Test(groups = "regression", description = "TC_CART_019: Sau khi dat hang – Back Home – gio reset = 0")
    public void sauDatHangGioResetVe0() {
        inventoryPage.themNSanPhamDauTien(2);
        cartPage = inventoryPage.diDenGioHang();
        CheckoutPage co = cartPage.nhanCheckout();
        co.nhapThongTin("Nguyen", "Van A", "70000").nhanContinue();
        co.nhanFinish();
        Assert.assertTrue(co.isDonHangHoanThanh());
        InventoryPage trangChu = co.nhanBackHome();
        Assert.assertEquals(trangChu.laySoLuongBadge(), 0,
                "Gio hang phai reset ve 0 sau khi dat hang xong");
        System.out.println("[PASS] TC_CART_019 – Gio hang reset = 0 sau dat hang");
    }

    // ──────────────────────────────────────────────────────────────────────────
    // YEU CAU 2.3.C: Kiem tra tinh toan tong tien
    // ──────────────────────────────────────────────────────────────────────────

    @Test(groups = "regression", description = "TC_CART_020: Kiem tra tinh toan Item total, Tax 8%, Total chinh xac")
    public void kiemTraTongTien() {
        // Them 3 san pham co gia khac nhau
        inventoryPage.themSanPhamTheoTen("Sauce Labs Backpack"); // $29.99
        inventoryPage.themSanPhamTheoTen("Sauce Labs Bike Light"); // $9.99
        inventoryPage.themSanPhamTheoTen("Sauce Labs Onesie"); // $7.99
        // Gia tri thuc se lay tu trang checkout step 2

        // Vao checkout step 2
        cartPage = inventoryPage.diDenGioHang();
        CheckoutPage co = cartPage.nhanCheckout();
        co.nhapThongTin("Nguyen", "Van A", "70000").nhanContinue();
        Assert.assertTrue(co.isDangOStep2(), "Phai o Step 2 de kiem tra tong tien");

        // Lay gia tri tu trang
        double itemTotal = co.layItemTotal();
        double tax = co.layTax();
        double total = co.layTotal();

        System.out.println("[INFO] Item total = $" + itemTotal);
        System.out.println("[INFO] Tax        = $" + tax);
        System.out.println("[INFO] Total      = $" + total);

        // Assert Tax = ItemTotal x 8% (sai so <= 0.01)
        Assert.assertTrue(
                Math.abs(tax - itemTotal * 0.08) < 0.01,
                String.format("Tax phai = ItemTotal x 8%%: %.2f x 8%% = %.2f, nhung Tax = %.2f",
                        itemTotal, itemTotal * 0.08, tax));

        // Assert Total = ItemTotal + Tax (sai so <= 0.01)
        Assert.assertTrue(
                Math.abs(total - (itemTotal + tax)) < 0.01,
                String.format("Total phai = ItemTotal + Tax: %.2f + %.2f = %.2f, nhung Total = %.2f",
                        itemTotal, tax, itemTotal + tax, total));

        System.out.println("[PASS] TC_CART_020 – Tinh toan chinh xac: "
                + itemTotal + " + " + tax + " = " + total);
    }

    // ──────────────────────────────────────────────────────────────────────────
    // NHOM 7: Problem User – ghi nhan bug
    // ──────────────────────────────────────────────────────────────────────────

    @Test(groups = "regression", description = "TC_CART_021: problem_user – them san pham, ghi nhan bug neu co")
    public void problemUserThemSanPham() {
        // Dang nhap lai bang problem_user
        getDriver().get(URL);
        LoginPage lp = new LoginPage(getDriver());
        lp.moTrang(URL);
        lp.dangNhap("problem_user", "secret_sauce");
        InventoryPage inv = new InventoryPage(getDriver());

        try {
            inv.themNSanPhamDauTien(1);
            int badge = inv.laySoLuongBadge();
            if (badge != 1) {
                System.out.println("[BUG] TC_CART_021 – problem_user: Badge = "
                        + badge + " (mong doi 1) – CO BUG!");
            } else {
                System.out.println("[PASS] TC_CART_021 – problem_user: badge = 1, khong co bug them san pham");
            }
            // Khong Assert cung – chi ghi nhan, problem_user co the co bug
        } catch (Exception e) {
            System.out.println("[BUG] TC_CART_021 – problem_user: Exception khi them san pham: "
                    + e.getMessage());
        }
    }
}
